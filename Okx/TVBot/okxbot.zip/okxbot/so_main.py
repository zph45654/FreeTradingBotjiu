from otbot import *

bot = StartBot()
bot.run()