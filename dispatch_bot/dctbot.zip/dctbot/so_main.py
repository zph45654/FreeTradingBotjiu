from dctbot import *

# StartBot().run()
RunDcBot()